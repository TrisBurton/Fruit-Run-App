﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapGenerator : MonoBehaviour {

	public static MapGenerator instance; // MapGenerator.instance allows us to access all of its public variables.

	public GameObject
	waterPrefab,
	grass_Prefab,
	groundPrefab_1,
	groundPrefab_2,
	groundPrefab_3,
	groundPrefab_4,
	grass_Bottom_Prefab,
	land_Prefab_1,
	land_Prefab_2,
	land_Prefab_3,
	land_Prefab_4,
	land_Prefab_5,
	big_Grass_Prefab,
	big_Grass_Bottom_Prefab,
	treePrefab_1,
	treePrefab_2,
	treePrefab_3,
	big_Tree_Prefab; // Game objects used to create our levels.

	public GameObject
	water_Holder,
	top_Near_Side_Walk_Holder,
	top_Far_Side_Walk_Holder,
	bottom_Near_Side_Walk_Holder,
	bottom_Far_Side_Walk_Holder; // Parent Game Objects
	// Public variables, so able to adjust in the inspector panel.
	public int
	start_Water_Tile, // initialization number of ' road tiles '. The amount of road tiles.
	start_Grass_Tile, // initialization number of ' grass tiles '. The amount of grass tiles.
	start_Ground3_Tile, // initialization number of ' ground3 tiles '. The amount of ground3 tiles.
	start_Land_Tile; // initialization number of ' land tiles '. The amount of land tiles.

	public List<GameObject>
	water_Tiles,
	top_Near_Grass_Tiles,
	top_Far_Grass_Tiles,
	bottom_Near_Grass_Tiles,
	bottom_Far_Land_F1_Tiles,
	bottom_Far_Land_F2_Tiles,
	bottom_Far_Land_F3_Tiles,
	bottom_Far_Land_F4_Tiles,
	bottom_Far_Land_F5_Tiles; // Stored game objects, public to be used in other classes.

	// Positions for ground1 on top from 0 to startGround3Tile.
	public int[] pos_For_Top_Ground_1;

	// Positions for ground2 on top from 0 to startGround3Tile.
	public int[] pos_For_Top_Ground_2;

	// Positions for ground4 on top from 0 to startGround3Tile.
	public int[] pos_For_Top_Ground_4;

	// positions for big grass with tree on top near grass from 0 to startGrassTile
	public int[] pos_For_Top_Big_Grass;

	// positions for tree1 on top near grass from 0 to startGrassTile
	public int[] pos_For_Top_Tree_1;

	// positions for tree 2 on top near grass from 0 to startGrassTile
	public int[] pos_For_Top_Tree_2;

	// positions for tree3 on top near grass from 0 to startGrassTile
	public int[] pos_For_Top_Tree_3;


	// position for road tile on water from 0 to startRoadTile
	public int pos_For_Water_Tile_1;

	// position for road tile on water from 0 to startRoadTile
	public int pos_For_Water_Tile_2;

	// position for road tile on water from 0 to startRoadTile
	public int pos_For_Water_Tile_3;

	// position for BIG GRASS TREE on bottom near grass from 0 to startRoadTile
	public int[] pos_For_Bottom_Big_Grass;

	// positions for tree1 on bottom near grass from 0 to startGrassTile
	public int[] pos_For_Bottom_Tree1;

	//positions for tree2 on bottom near grass from 0 to startGrassTile
	public int[] pos_For_Bottom_Tree2;

	//positions for tree3 on bottom near grass from 0 to startGrassTile
	public int[] pos_For_Bottom_Tree3;

	// Not visible in the inspector panel.
	[HideInInspector]
	public Vector3
	last_Pos_Of_Water_Tile,
	last_Pos_Of_Top_Near_Grass,
	last_Pos_Of_Top_Far_Grass,
	last_Pos_Of_Bottom_Near_Grass,
	last_Pos_Of_Bottom_Far_Land_F1,
	last_Pos_Of_Bottom_Far_Land_F2,
	last_Pos_Of_Bottom_Far_Land_F3,
	last_Pos_Of_Bottom_Far_Land_F4,
	last_Pos_Of_Bottom_Far_Land_F5;

	[HideInInspector]
	public int
	last_Order_Of_Water,
	last_Order_Of_Top_Near_Grass,
	last_Order_Of_Top_Far_Grass,
	last_Order_Of_Bottom_Near_Grass,
	last_Order_Of_Bottom_Far_Land_F1,
	last_Order_Of_Bottom_Far_Land_F2,
	last_Order_Of_Bottom_Far_Land_F3,
	last_Order_Of_Bottom_Far_Land_F4,
	last_Order_Of_Bottom_Far_Land_F5; // ORDER OF VARIABLES IN RENDERING HIERARCHY.


	void Awake()
	{
		MakeInstance ();
	}

	// Use this for initialization
	void Start () {
		Initialize ();

	}

	// Update is called once per frame
	void MakeInstance () {

		if(instance == null)
		{
			instance = this; // referring to the MapGenerator class.
		} else if (instance != null) {
			Destroy (gameObject); // Destroys duplicate gameObject 
		}
	}

	void Initialize() {

		InitializePlatform (waterPrefab, ref last_Pos_Of_Water_Tile, waterPrefab.transform.position,
			start_Water_Tile, water_Holder, ref water_Tiles, ref last_Order_Of_Water,
			new Vector3(1.5f, 0f, 0f));

		InitializePlatform (grass_Prefab, ref last_Pos_Of_Top_Near_Grass, grass_Prefab.transform.position,
			start_Grass_Tile, top_Near_Side_Walk_Holder, ref top_Near_Grass_Tiles,
			ref last_Order_Of_Top_Near_Grass, new Vector3(1.2f, 0f, 0f));

		InitializePlatform (groundPrefab_3, ref last_Pos_Of_Top_Far_Grass, groundPrefab_3.transform.position,
			start_Ground3_Tile, top_Far_Side_Walk_Holder, ref top_Far_Grass_Tiles,
			ref last_Order_Of_Top_Far_Grass, new Vector3 (4.8f, 0f, 0f));

		InitializePlatform (grass_Bottom_Prefab, ref last_Pos_Of_Bottom_Near_Grass,
			new Vector3 (2.0f, grass_Bottom_Prefab.transform.position.y, 0f),
			start_Grass_Tile, bottom_Near_Side_Walk_Holder, ref bottom_Near_Grass_Tiles,
			ref last_Order_Of_Bottom_Near_Grass, new Vector3 (1.2f, 0f, 0f));

		InitializeBottomFarLand ();

	} // Initialize

	void InitializePlatform(GameObject prefab, ref Vector3 last_Pos, Vector3 last_Pos_Of_Tile,
		int amountTile, GameObject holder, ref List<GameObject> list_Tile, ref int last_Order, Vector3 offset) {

		int orderInLayer = 0;
		last_Pos = last_Pos_Of_Tile;

		for (int i = 0; i < amountTile; i++) {

			GameObject clone = Instantiate (prefab, last_Pos, prefab.transform.rotation) as GameObject; // Creates game object that we pass.
			clone.GetComponent<SpriteRenderer>().sortingOrder = orderInLayer; // Used to determine rendering order of our game objects.

			if (clone.tag == MyTags.TOP_NEAR_GRASS) {

				SetNearScene (big_Grass_Prefab, ref clone, ref orderInLayer, pos_For_Top_Big_Grass,
					pos_For_Top_Tree_1, pos_For_Top_Tree_2, pos_For_Top_Tree_3);

			} else if (clone.tag == MyTags.BOTTOM_NEAR_GRASS) {

				SetNearScene (big_Grass_Bottom_Prefab, ref clone, ref orderInLayer,
					pos_For_Bottom_Big_Grass, pos_For_Bottom_Tree1, pos_For_Bottom_Tree2,
					pos_For_Bottom_Tree3);


			} else if (clone.tag == MyTags.BOTTOM_FAR_LAND_2) {

				if (orderInLayer == 5) {
					CreateTreeOrGround (big_Tree_Prefab, ref clone, new Vector3 (-0.57f, -1.34f, 0f));
				}


			} else if (clone.tag == MyTags.TOP_FAR_GRASS) {

				CreateGround (ref clone, ref orderInLayer);

			}

			clone.transform.SetParent (holder.transform); // Setting game object to be a child under antoher game object.
			list_Tile.Add (clone); // Stores game object in the given list.

			orderInLayer += 1; // Increase order layer to control the rendering of our game object.
			last_Order = orderInLayer;

			last_Pos += offset; // Determines where our game object will be rendered.

		} // FOR LOOP


	} // InitializePlatform

	void CreateScene(GameObject bigGrassPrefab, ref GameObject tileClone, int orderInLayer)
	{
		GameObject clone = Instantiate (bigGrassPrefab, tileClone.transform.position,
			bigGrassPrefab.transform.rotation) as GameObject; // Creates a duplicate big grass prefab, stored at tileClone position, must provide rotation variable as it is a parameter required by the Instantiate function. 

		clone.GetComponent<SpriteRenderer> ().sortingOrder = orderInLayer; // Order in the same sorting layer, determines which game object will be rendered on top of each other.
		clone.transform.SetParent (tileClone.transform); // setting clone to be the child of tileClone.
		clone.transform.localPosition = new Vector3 (-0.183f, 0.106f, 0f); // Local position relative to the parent.

		CreateTreeOrGround (treePrefab_1, ref clone, new Vector3 (0f, 1.52f, 0f)); // Creating a tree

		// Turn off parent tile to show child tile
		tileClone.GetComponent<SpriteRenderer> ().enabled = false;

	} // Create Scene

	void CreateTreeOrGround(GameObject prefab, ref GameObject tileClone, Vector3 localPos) {

		GameObject clone = Instantiate (prefab, tileClone.transform.position, prefab.transform.rotation)
			as GameObject; // Instantiate creates a game object prefab at a new position using rotation.

		SpriteRenderer tileCloneRenderer = tileClone.GetComponent<SpriteRenderer> (); // Taking the renderer from the parent - tileClone
		SpriteRenderer cloneRenderer = clone.GetComponent<SpriteRenderer> (); // Taking the renderer from the child - clone

		cloneRenderer.sortingOrder = tileCloneRenderer.sortingOrder; // Setting the child's sorting order to the parents.
		clone.transform.SetParent (tileClone.transform); // Setting the child under the parent.
		clone.transform.localPosition = localPos; // Setting child's localPosition under localPos.

		if (prefab == groundPrefab_1 || prefab == groundPrefab_2 || prefab == groundPrefab_4)
		{
			tileCloneRenderer.enabled = false; // Hide the parent to show the child 
		}

	} // CreateTreeOrGround

	void CreateGround(ref GameObject clone, ref int orderInLayer)
	{
		for (int i = 0; i < pos_For_Top_Ground_1.Length; i++) 
		{	// If order layer equals element at [i] index at pos_For_Top_Ground_1
			if (orderInLayer == pos_For_Top_Ground_1 [i]) 
			{
				CreateTreeOrGround (groundPrefab_1, ref clone, Vector3.zero); // Vector3.zero local position and passing the cloned groundPrefab_1 which is a parent of the ground.
				break; // To only create one ground.
			} // If Statement

		} // For Loop

		for (int i = 0; i < pos_For_Top_Ground_2.Length; i++) 
		{
			if (orderInLayer == pos_For_Top_Ground_2 [i]) 
			{
				CreateTreeOrGround (groundPrefab_2, ref clone, Vector3.zero);
				break; // To only create one ground.
			} // If Statement

		} // For Loop

		for (int i = 0; i < pos_For_Top_Ground_4.Length; i++) 
		{
			if (orderInLayer == pos_For_Top_Ground_4 [i]) 
			{
				CreateTreeOrGround (groundPrefab_4, ref clone, Vector3.zero);
				break; // To only create one ground.
			} // If Statement

		} // For Loop

	} // CreateGround

	void SetNearScene(GameObject bigGrassPrefab, ref GameObject clone, ref int orderInLayer,
		int[] pos_For_BigGrass, int[] pos_For_Tree1, int[] pos_For_Tree2, int[] pos_For_Tree3)
	{
		for (int i = 0; i < pos_For_BigGrass.Length; i++) 
		{
			if (orderInLayer == pos_For_BigGrass [i]) 
			{
				CreateScene (bigGrassPrefab, ref clone, orderInLayer);
				break;
			} // If statement

		} // For Loop

		for (int i = 0; i < pos_For_Tree1.Length; i++) {
			if (orderInLayer == pos_For_Tree1 [i]) {
				CreateTreeOrGround (treePrefab_1, ref clone, new Vector3 (0f, 1.15f, 0f));
				break;
			} // Going through iteration. If the orderInLayer equals the element at [i] index at the position pos_ForTree1. Then create treePrefab_1.

		}

		for (int i = 0; i < pos_For_Tree2.Length; i++) {
			if (orderInLayer == pos_For_Tree2 [i]) {
				CreateTreeOrGround (treePrefab_2, ref clone, new Vector3 (0f, 1.15f, 0f));
				break; // Creating treePrefab_2 from instantiation at a specific position.
			}

		}

		for (int i = 0; i < pos_For_Tree3.Length; i++) {
			if (orderInLayer == pos_For_Tree3 [i]) {
				CreateTreeOrGround (treePrefab_3, ref clone, new Vector3 (0f, 1.15f, 0f));
				break; // Creating treePrefab_3 from instantiation at a specific position.
			}

		}

	} // SetNearScene

	void InitializeBottomFarLand()
	{
		InitializePlatform (land_Prefab_1, ref last_Pos_Of_Bottom_Far_Land_F1, land_Prefab_1.transform.position,
			start_Land_Tile, bottom_Far_Side_Walk_Holder, ref bottom_Far_Land_F1_Tiles,
			ref last_Order_Of_Bottom_Far_Land_F1, new Vector3 (1.6f, 0f, 0f));

		InitializePlatform (land_Prefab_2, ref last_Pos_Of_Bottom_Far_Land_F2, land_Prefab_2.transform.position,
			start_Land_Tile - 3, bottom_Far_Side_Walk_Holder, ref bottom_Far_Land_F2_Tiles,
			ref last_Order_Of_Bottom_Far_Land_F2, new Vector3 (1.6f, 0f, 0f));

		InitializePlatform (land_Prefab_3, ref last_Pos_Of_Bottom_Far_Land_F3, land_Prefab_3.transform.position,
			start_Land_Tile - 4, bottom_Far_Side_Walk_Holder, ref bottom_Far_Land_F3_Tiles,
			ref last_Order_Of_Bottom_Far_Land_F3, new Vector3 (1.6f, 0f, 0f));

		InitializePlatform (land_Prefab_4, ref last_Pos_Of_Bottom_Far_Land_F4, land_Prefab_4.transform.position,
			start_Land_Tile - 7, bottom_Far_Side_Walk_Holder, ref bottom_Far_Land_F4_Tiles,
			ref last_Order_Of_Bottom_Far_Land_F4, new Vector3 (1.6f, 0f, 0f));

		InitializePlatform (land_Prefab_5, ref last_Pos_Of_Bottom_Far_Land_F5, land_Prefab_5.transform.position,
			start_Land_Tile - 10, bottom_Far_Side_Walk_Holder, ref bottom_Far_Land_F5_Tiles,
			ref last_Order_Of_Bottom_Far_Land_F5, new Vector3 (1.6f, 0f, 0f));


	} // InitializeBottomFarLand

} // class












































































