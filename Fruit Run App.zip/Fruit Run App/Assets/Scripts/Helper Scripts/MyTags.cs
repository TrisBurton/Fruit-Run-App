﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MyTags : MonoBehaviour {

	public static string WATER = "Water";
	public static string TOP_NEAR_GRASS = "TopNearGrass";
	public static string TOP_FAR_GRASS = "TopFarGrass";
	public static string BOTTOM_NEAR_GRASS = "BottomNearGrass";
	public static string BOTTOM_FAR_LAND_1 = "BottomFarLand1";
	public static string BOTTOM_FAR_LAND_2 = "BottomFarLand2";
	public static string BOTTOM_FAR_LAND_3 = "BottomFarLand3";
	public static string BOTTOM_FAR_LAND_4 = "BottomFarLand4";
	public static string BOTTOM_FAR_LAND_5 = "BottomFarLand5";
	public static string OBSTACLE = "Obstacle";
	public static string STAR = "Star";
	public static string STAR_EFFECT = "Star Effect";
	public static string OB_TOP = "ObTop";
	public static string OB_BOTTOM = "ObBottom";
	public static string OB_MIDDLE = "ObMiddle";
	public static string T_REX = "Trex";
	public static string APPLE = "Apple";
	public static string AUBERGINE = "Aubergine";
	public static string AVOCADO = "Avocado";
	public static string BANANA = "Banana";
	public static string DUMBBELL = "Dumbbell";
	public static string FOOTBALL = "Football";
	public static string FOOTBALLER = "Footballer";
	public static string FRUITS = "Fruits";
	public static string JAMAICA = "Jamaica";
	public static string KETTLEBELL = "Kettlebell";
	public static string LEMON = "Lemon";
	public static string MANGO = "Mango";
	public static string ORANGE = "Orange";
	public static string PEPPER = "Pepper";
	public static string PINEAPPLE = "Pineapple";
	public static string STRAWBERRY = "Strawberry";
	public static string TOMATO = "Tomato";
	public static string WATERMELON = "Watermelon";

	public static string SORTING_LAYER_TOP_NEAR_GROUND = "Top near ground";
	public static string SORTING_LAYER_TREE_TOP = "Tree top";
	public static string SORTING_LAYER_BOTTOM_NEAR_GROUND = "Bottom near ground";
	public static string SORTING_LAYER_TREE_BOTTOM = "Tree bottom";




} // class

















































































