﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CharacterSelectScript : MonoBehaviour {

	public GameObject[] available_Heroes;

	private int currentIndex;

	public Text selectedText;
	public GameObject starIcon;
	public Image selectBtn_Image;
	public Sprite button_Green, button_Blue;

	private bool[] heroes; // Used in Game Manager, lets us know which heroes are activated.

	public Text starScoreText;

	void Start () {
		InitializeCharacters ();
	}

	void InitializeCharacters() {
		currentIndex = GameManager.instance.selected_Index; // Setting the currentIndex to the character selected by the user in the GameManager.

		for(int i = 0; i < available_Heroes.Length; i++) {
			available_Heroes[i].SetActive (false); // Deactivates all heroes.
		}
		available_Heroes[currentIndex].SetActive (true); // With current index, activates the current selected hero.

		heroes = GameManager.instance.heroes; // Gets hero selection from the GameManager.

	}

	public void NextHero() {
		available_Heroes [currentIndex].SetActive (false); // When we click to go onto the next hero, we deactivate the current hero that was selected.

		if (currentIndex + 1 == available_Heroes.Length) {
			currentIndex = 0; // NextHero to the right side equivalent to +1. We receive a null reference exception if the if statement is true (available_Heroes.Length - length of array, gives a null exception).
			// Goes back to the first element in the array, represented by 0.
		} else {
			currentIndex++; // Go to the next element in the array. Incrementation from currentIndex++.
		}

		available_Heroes [currentIndex].SetActive (true);

		CheckIfCharacterIsUnlocked (); // Checks if the character is locked.

	}

	public void PreviousHero() {
		available_Heroes [currentIndex].SetActive (false); // Deactivate the current hero selected.

		if (currentIndex - 1 == -1) {
			currentIndex = available_Heroes.Length - 1; // -1 to represent left side and going backwards in array.

		} else {
			currentIndex--; // Decrement and go backwards.
		}
		available_Heroes [currentIndex].SetActive (true);

		CheckIfCharacterIsUnlocked (); // Checks if the character is locked.
			
	}

	void CheckIfCharacterIsUnlocked() {
		if (heroes [currentIndex]) { // If the game object is active.
			// If the hero is unlocked, deactivate the star icon.  
			starIcon.SetActive (false);
			// If the currentIndex is not equal to the saved index in our game data.
			if (currentIndex == GameManager.instance.selected_Index) {
				selectBtn_Image.sprite = button_Green; // Then the selected button sprite will be equal to the green button.
				selectedText.text = "Selected"; // Selects the character.
			} else {
				selectBtn_Image.sprite = button_Green;
				selectedText.text = "Select?"; // Prompts the user. Do you want to select this player? 
			}

		} else {
			// If the hero is LOCKED.
			selectBtn_Image.sprite = button_Blue; // If character is locked the button will be blue.
			starIcon.SetActive (true); // Star Icon will appear.
			selectedText.text = "500"; // How much our players will cost.
		}

	}
	// If our hero is LOCKED.
	public void SelectHero() {
		if (!heroes [currentIndex]) { 

			if (currentIndex != GameManager.instance.selected_Index) { // The current index is not equal to the selected index that is saved in our GameManager.
				// Unlock hero if you have enough stars.
				if (GameManager.instance.star_Score >= 500) { // If the user's star coins is greater or equal to 500.
					GameManager.instance.star_Score -= 500; // Subtract 500 stars from player.

					selectBtn_Image.sprite = button_Green; // Selected button image sprite is green.
					selectedText.text = "Selected"; // Displays the character is selected.
					starIcon.SetActive (false); // Deactivates star icon.
					heroes [currentIndex] = true; // Heroes and elements at the current index is unlocked.

					starScoreText.text = GameManager.instance.star_Score.ToString (); // starScoreText.text equals to the new star score as we subtracted 500 stars from the user.

					GameManager.instance.selected_Index = currentIndex; // Saves current selected hero.
					GameManager.instance.heroes = heroes; // Saved heroes array, allows us to have data storing which characters are unlocked.

					GameManager.instance.SaveGameData (); // Saves game data.
				} else {
					print ("HAVE ANOTHER FRUIT RUN TO GET MORE STARS AND UNLOCK THIS PLAYER");
				}

			}

			} else {
				selectBtn_Image.sprite = button_Green; // Button image greeen when unlocked. 
				selectedText.text = "Selected"; // Character is selected.
				GameManager.instance.selected_Index = currentIndex; // Saves the current selected index/game object.
				GameManager.instance.SaveGameData (); // Saves game data.
			}
		}

} // class








































































