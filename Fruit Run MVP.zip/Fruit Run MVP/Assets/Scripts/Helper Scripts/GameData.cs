﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


[Serializable] // Class Must be serializable for us to save our game data using Binary input and output.
public class GameData {

	private int star_Score; // Controls star_Score amount in-game.
	private int score_Count; // Controls score_Count amount in-game.

	private bool[] heroes; // Controls which hero's are locked or unlocked.

	private int selected_Index; // Which current hero is selected.

	// This public accesser will allow us to edit the star_Score.
	public int StarScore {
		get {
			return star_Score;
		}
		set {
			star_Score = value;
		}
	}
	// This public accesser will allow us to edit the score_Count.
	public int ScoreCount {
		get {
			return score_Count;
		}
		set {
			score_Count = value;
		}
	}
	// This public bool will control whether hero's are locked or unlocked.
	public bool[] Heroes {
		get {
			return heroes; 
		}
		set {
			heroes = value; 
		}
	}
	// This will allow us to determine the current hero selected.
		public int SelectedIndex {
			get {
				return selected_Index;
			}
			set {
				selected_Index = value;
			}
		}


} // class
