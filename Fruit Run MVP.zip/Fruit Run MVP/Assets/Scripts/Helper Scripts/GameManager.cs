﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

public class GameManager : MonoBehaviour {

	public static GameManager instance; // Game data stored can be accessed using the GameManager instance.

	private GameData gameData; // gameData storage reference required to align with SaveGameData() class. Game Data should not be null when we try to save it.

	[HideInInspector]
	public int star_Score, score_Count, selected_Index;

	[HideInInspector]
	public bool playSound = true;

	[HideInInspector]
	public bool[] heroes; // Will hold any unlocked heroes in user gameplay within the boolean array.

	// private string data_Path = "GameData.dat"; // Allows us to pass data_Path instead of "GameData.dat" within our code. However brings errors so commented out.

	void Awake () {
		MakeSingleton ();
		InitializeGameData ();
	}

	void MakeSingleton() {
		if (instance != null) {
			Destroy (gameObject);
		} else if (instance == null) {
			instance = this;
			DontDestroyOnLoad (gameObject);
		}
	}

	void InitializeGameData() {
		LoadGameData (); // Loading game data.

		if (gameData == null) {
			// We are running our game for the first time.
			// Set up intial values.
			star_Score = 0; // Sets star score in-game to equal 0.
			score_Count = 0; // Sets score count in-game to equal 0.
			selected_Index = 0; 

			heroes = new bool[9]; // Amount of heroes available within our game.
			heroes [0] = true; // First hero is unlocked.

			for (int i = 1; i < heroes.Length; i++) {
				heroes [i] = false; // All other heroes are locked.
			}

			gameData = new GameData (); // Create new game data that we can save.
			gameData.StarScore = star_Score;
			gameData.ScoreCount = score_Count;
			gameData.Heroes = heroes;
			gameData.SelectedIndex = selected_Index;

			SaveGameData (); // Saves our new game data.
		}

	}

	// Public to be called by instance to save game data when needed.
	public void SaveGameData(){ // Saving Game Data.
		FileStream file = null; // Creates a file which will be stored on our computer. Saves game data.
		// Created try and catch block. When dealing with saving data, as when trying to open a file it may not exist or be created. C#/Compiler will throw an exception, exceptions allow our program to run on the user's phone without crashing.
		try {
			BinaryFormatter bf = new BinaryFormatter (); // Encrypts game data.
			// If there is a problem with the code here, we will exit the try block, going into the catch block to catch the exception and the code above the catch block will not be executed.
			file = File.Create (Application.persistentDataPath + "GameData.dat"); // Contains the path to a persistent data directory, appended GameData.dat is the name of our file for game data.
			// If game data is not equal to null.
			if (gameData != null) {
				gameData.Heroes = heroes; // Refers to our heroes which is accessed by the public accesser in C# GameData script. Data to be saved for the next time we run our game.
				gameData.StarScore = star_Score; // Saved data for the amount of stars users have collected for the next time they run the game.
				gameData.ScoreCount = score_Count; // Saved data of the users score_Count.
				gameData.SelectedIndex = selected_Index; // Allows us to have persistent data, thus enhancing user experience and allowing game progression. 

				bf.Serialize (file, gameData); // Serialize encrypts game data at this location, this prevents it from being hacked easily from having an extra layer of security.
			}

		} catch (Exception e) {

		} finally {
			if (file != null) { // If our file is not equal to null.
				file.Close (); // When we open a file we must close it when we do not want to use it anymore, prevents problems with the game, for example memory leaks.
			}
		}
	
	} // Finally clause will be executed whether we have an exception or not.

	void LoadGameData() {

		FileStream file = null; // Opens file.

		try {

			BinaryFormatter bf = new BinaryFormatter(); // Create binary formatter as file has previously been Serialized/Encrypted. Must now be Decrypted/Deserialized.

			file = File.Open(Application.persistentDataPath + "Gamedata.dat", FileMode.Open); // File open at this location, FileMode.Open.

			gameData = (GameData)bf.Deserialize(file); // (GameObject) casting allows us to convert and store in gameData.Loads game data from it being decrypted.
			// If gameData is not equal to null then we will retrieve all game data values below.
			if (gameData != null) {
				star_Score = gameData.StarScore;
				score_Count = gameData.ScoreCount;
				heroes = gameData.Heroes;
				selected_Index = gameData.SelectedIndex;
			}

		} catch (Exception e) {

		} finally {
			if (file != null) {
				file.Close (); // When a file is opened it must be closed to prevent memory leaks.
			}
		}
	}

} // class
