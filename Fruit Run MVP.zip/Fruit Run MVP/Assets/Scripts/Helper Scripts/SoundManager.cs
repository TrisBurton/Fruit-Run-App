﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManager : MonoBehaviour {

	public static SoundManager instance;

	public AudioSource
		move_Audio_Source,
		jump_Audio_Source,
		powerUp_Die_AudioSource,
		background_Audio_Source; // Creating public variables to be attached inside inspector panel.

	public AudioClip
		power_Up_Clip,
		die_Clip,
		coin_Clip, // Represents the sound for our stars in game.
		game_Over_Clip; // Public audio clips, as some will be changed in script.

	void Awake () {
		MakeInstance ();
	}

	void Start() {
		//Test if we should play background music mix-kit-need-for-speed
		if (GameManager.instance.playSound) {
			background_Audio_Source.Play (); // Plays background music.
		} else {
			background_Audio_Source.Stop (); // Stop playing background music.
		}
	}
	
	void MakeInstance () {
		if (instance == null) {
			instance = this;
		} else if (instance != null) {
			Destroy (gameObject);
		
		}
	}

		public void PlayMoveLineSound() {
		move_Audio_Source.Play (); // When we move left and right on the road we will play this sound.
		}

	public void PlayJumpSound() {
		jump_Audio_Source.Play (); // When our player jumps, this sound will be played.
	}

	public void PlayDeadSound() {
		powerUp_Die_AudioSource.clip = die_Clip; // Changed clip inside audio source to die_Clip.
		powerUp_Die_AudioSource.Play (); // When our player dies, we will call our powerUp_Die_AudioSource script and this sound will be played.
	}

	public void PlayPowerUpSound() {
		powerUp_Die_AudioSource.clip = power_Up_Clip; // Change the clip to power_Up.
		powerUp_Die_AudioSource.Play (); // When our player receives a powerUp this sound will be played.
	}

	public void PlayCoinSound() {
		powerUp_Die_AudioSource.clip = coin_Clip; // Represents our star collectibles.
		powerUp_Die_AudioSource.Play (); // When our player collects stars, this sound will be played.
	}

	public void PlayGameOverClip() {
		background_Audio_Source.Stop (); // Stops the background music from playing.
		background_Audio_Source.clip = game_Over_Clip; // Change the clip to the sound effect game_Over clip.
		background_Audio_Source.loop = false; // Loop is false to ensure when game_Over sound is played its only for once cycle.
		background_Audio_Source.Play (); // Plays sound effect.
	}


} // class
