﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleHolder : MonoBehaviour {

	public GameObject[] childs; // Obstacles of specific obstacle holder.

	public float limitAxisX; // The position X where the obstacles can go before we turn it off.

	public Vector3
		firstPos,
		secondPos; // Represents the left (firstPos) side of the road and right (secondPos) side of the road.

	// Update is called once per frame
	void Update () {
		transform.position += new Vector3 (-GameplayController.instance.moveSpeed * Time.deltaTime, 0f, 0f); 
		// Moving the position of the obstacle holder to the left side.
		if (transform.localPosition.x <= limitAxisX) {
			GameplayController.instance.obstacles_Is_Active = false; // Inform the gameplay controller that the obstacle is not active.
			gameObject.SetActive(false); // Deactivate and inform the gameplay controller that it isn't active anymore.
		}
	} // Using -GameplayController as we are on the left side which is negative.

	// Is called second when the game starts and every time the game object is enabled or disabled.
	void OnEnable() {
		for (int i = 0; i < childs.Length; i++) {
			childs [i].SetActive (true); // Activates the children via for loop.
	}

		if (Random.value <= 0.5f) {
			transform.localPosition = firstPos;
		} else {
			transform.localPosition = secondPos; 
		}

	} // Random50/50 chance of player being positioned either starting on left or right side of road.

} // class
