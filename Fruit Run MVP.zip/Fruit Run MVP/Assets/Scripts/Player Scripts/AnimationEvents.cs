﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimationEvents : MonoBehaviour {

	private Animator anim;

	private string walk_Animation = "PlayerWalk";

	void Awake () {
		anim = GetComponent<Animator> (); 
	}
	
	// Update is called once per frame
	void PlayerWalkAnimation () {
		anim.Play (walk_Animation);

		if (PlayerController.instance.player_Jumped) {
			PlayerController.instance.player_Jumped = false; 
		} // Attached on ChangeLine animation and Jump animation
	}

	void AnimationEnded() {
		gameObject.SetActive (false); // After animation ends, it is no longer needed so set to false.
	}

	void PausePanelClose() {
		Time.timeScale = 1f;
		gameObject.SetActive (false); // Deactivates the pause panel 
	}
		

} // class
