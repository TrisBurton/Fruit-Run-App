﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

	public static PlayerController instance;

	private Animator anim;

	private string jump_Animation = "PlayerJump", change_Line_Animation = "ChangeLine"; // Shortcut for typing two lines of private strings instead use "," to adjoin the two.

	public GameObject
		player,
		shadow; 

	public Vector3	
		first_PosOfPlayer,
		second_PosOfPlayer;

	[HideInInspector]
	public bool player_Died; // Must be public for it to be accessed from other classes, but not visible in the Inspector panel.

	[HideInInspector]
	public bool player_Jumped;

	public GameObject explosion;

	private SpriteRenderer player_Renderer;
	public Sprite TRex_Sprite, player_Sprite;

	private bool TRex_Trigger; // Detect when we collide with TRex.

	private GameObject[] star_Effect;

	void Awake() {
		MakeInstance ();

		anim = player.GetComponent<Animator> (); // Retrieves player animation component.

		player_Renderer = player.GetComponent<SpriteRenderer> ();

		star_Effect = GameObject.FindGameObjectsWithTag (MyTags.STAR_EFFECT); // Get star effect game objects.
	}

	void Start () {
		string path = "Resources/Sprites/Player/hero" + GameManager.instance.selected_Index + "_big"; // Creating a path in our sprites/player/hero location. Loads appropiate player in-game.
		player_Sprite = Resources.Load<Sprite> (path); // When Resources.Load is used you must load the Resources folder containing the content. 
		player_Renderer.sprite = player_Sprite;
		
	}
	
	void Update () {

		HandleChangeLine ();
		HandleJump ();
		
	}

	void MakeInstance() {
		if (instance == null) {
			instance = this;
		} else if (instance != null) {
			Destroy (gameObject);
		}

	}

	void HandleChangeLine() {

		if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W)) {

			anim.Play (change_Line_Animation); // When up arrow or W key is pressed, changeLine animaion is played.
			transform.localPosition = second_PosOfPlayer; // Changes position of the player to the second position.

			SoundManager.instance.PlayMoveLineSound ();
		} else if (Input.GetKeyDown (KeyCode.DownArrow) || Input.GetKeyDown (KeyCode.S)) {

			anim.Play (change_Line_Animation); // When down arrow or S key is pressed, player moves to first position.
			transform.localPosition = first_PosOfPlayer;
			}

		SoundManager.instance.PlayMoveLineSound ();
	} // HandleChangeLine() class

	void HandleJump() {

		if (Input.GetKeyDown (KeyCode.Space)) {
			if (!player_Jumped) {
				
				anim.Play (jump_Animation); // If press key space, checks if player did not jump, then jump animation.
				player_Jumped = true; // Limit player jumping when in the air.
				SoundManager.instance.PlayJumpSound();
			}

		}

	}

	void Die() {
		player_Died = true; // Informs entire game that player_Died is true.
		player.SetActive (false); // Deactivates player game object.
		shadow.SetActive (false); // Deactivates player shadow.

		GameplayController.instance.moveSpeed = 0f; // Stops camera or anything else in-game from moving.
		GameplayController.instance.GameOver();
		SoundManager.instance.PlayDeadSound();
		SoundManager.instance.PlayGameOverClip ();
	}

	void DieWithObstacle(Collider2D target) {
		Die ();

		explosion.transform.position = target.transform.position; // Set explosion at position where our target (obstacle collided with) is.
		explosion.SetActive (true); // Calls explosion animation.
		target.gameObject.SetActive (false); // Deactivates obstacle.

		SoundManager.instance.PlayDeadSound ();
	}

	IEnumerator TRexDuration() {
		yield return new WaitForSeconds (7f); // 7 second power up.
		// Checks if we have a power-up (TRex).
		if (TRex_Trigger) {
			TRex_Trigger = false;  // TRex_Trigger

			player_Renderer.sprite = player_Sprite; // Sets player sprite image back to player renderer.
		}
	}

	void DestroyObstacle(Collider2D target) {
		explosion.transform.position = target.transform.position;
		explosion.SetActive (false); // Turns off explosion if it is already on.
		explosion.SetActive (true); 

		target.gameObject.SetActive (false);

		SoundManager.instance.PlayDeadSound ();
	}

	void OnTriggerEnter2D(Collider2D target) {
		// If our target.tag equals obstacle represents a collision.
		if (target.tag == MyTags.OBSTACLE) {
			// If we do not have TREx_Trigger (represents no power-up).
			if (!TRex_Trigger) {
				DieWithObstacle (target); // Player dies with obstacle, calls void Die() class.
			} else {
				DestroyObstacle (target); // Destroys target game object which is passed.
			}
		}
		if (target.tag == MyTags.T_REX) {
			TRex_Trigger = true; // We now have a power-up
			player_Renderer.sprite = TRex_Sprite; // Displays player as TRex - we now have a power-up.
			target.gameObject.SetActive (false); // Deactivate power pick-up TRex.

			SoundManager.instance.PlayPowerUpSound ();

			StartCoroutine (TRexDuration ()); // Calling coroutine TRexDuration().
		}
		// target in this if statement is the star
		if (target.tag == MyTags.STAR) { // When user collides with the star.

			for (int i = 0; i < star_Effect.Length; i++) { // Iterate through star_Effect
				if (!star_Effect [i].activeInHierarchy) { // Check first star that is not active in hierarchy.
					star_Effect [i].transform.position = target.transform.position; // pick up star with particles coming out of it, collected at that position.
					star_Effect [i].SetActive (true); // Activates star_Effect.
					break; // When this is true we break out of the for loop, preventing other star_Effect game objects from activating.
				} // We only want one star_Effect.
			}

			target.gameObject.SetActive (false); // Deactivates star we picked up.
			SoundManager.instance.PlayCoinSound();
			// GAMEPLAY CONTROLLER INCREASE STAR SCORE
			GameplayController.instance.UpdateStarScore();
		}
	}
		
} // class
